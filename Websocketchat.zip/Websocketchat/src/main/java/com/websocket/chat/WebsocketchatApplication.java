package com.websocket.chat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsocketchatApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebsocketchatApplication.class, args);
    }

}